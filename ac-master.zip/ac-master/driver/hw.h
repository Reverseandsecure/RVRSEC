#ifndef HW_H
#define HW_H

#include "common.h"

NTSTATUS
ValidatePciDevices();

#endif