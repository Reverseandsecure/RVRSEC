#include "common.hpp"

namespace framework
{
	class state
	{

	};
}