#include "patch.hpp"

namespace framework {
patch::patch(char *image_name) {}

patch::~patch() {}
} // namespace framework